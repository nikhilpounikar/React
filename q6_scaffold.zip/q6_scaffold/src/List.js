import { Todo } from "./Todo";

export function List(props) {
  
  

    const {todos,handleRemove} = props;
    return (
      <div className="list">
        {todos.map((todo, i) => (
          <Todo index={i} handleRemove={handleRemove} key={i} todo={todo} />
        ))}
      </div>
    );
  
}
