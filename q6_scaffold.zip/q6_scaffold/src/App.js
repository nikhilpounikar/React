import "./styles.css";
import { Component } from "react";
import { List } from "./List";
import { Form } from "./Form";

export default class App extends Component {
  // add constructor and state here
  constructor() {
   super();

    this.state = {
      todos: [
        
      ]
    };
  }

  addToList = (text) => {

      let {todos} = this.state;
      let index = todos.indexOf(text);

      if(index === -1){
        todos.push(text);
      }

      this.setState(
        todos
      )

  }
  // create handleAdd and handleRemove functions here
  handleRemove = (index) => {

    let {todos} = this.state;
    //let index = todos.indexOf(text);

    todos.splice(index,1);

    this.setState(
      todos
    )

}

  render() {
    const {todos} = this.state;
    return (
      <div className="App">
        <span>Todo</span>
        <Form addToList={this.addToList}/>
        <List todos={todos} handleRemove={this.handleRemove}/>
      </div>
    );
  }
}
