
export  function Todo(props) {
  const {index,handleRemove,todo} = props;
    return (
      
      <div className="todo">
        <p>{todo.text}</p>
        <button onClick={()=>handleRemove(index)}>x</button>
      </div>
    );
  
}
